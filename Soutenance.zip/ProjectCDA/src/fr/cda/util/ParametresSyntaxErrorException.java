package fr.cda.util;

// TODO: Auto-generated Javadoc
/**
 * The Class ParametresSyntaxErrorException.
 */
public class ParametresSyntaxErrorException extends RuntimeException
{
    
    /**
     * Instantiates a new parametres syntax error exception.
     *
     * @param texte the texte
     */
    public ParametresSyntaxErrorException(String texte)
    {
        super(texte);
    }
}